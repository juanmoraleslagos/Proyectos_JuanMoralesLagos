<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="agenda-rapida2.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="validacionesAgendaRapida.js"></script>
</head>
<body>
    <form action="" method="post">
        <div class="tituloprincipal">
            <h1>Reservar hora</h1>
        </div> 
        <div class="div3">
            
        <div class="heading-title">
            <h2>Reserva de hora medica</h2>
        </div>
        <div class="panel-body">
            <table id="customers">
                <tr>
                    <th><label>Centro médico de preferencia</label></th>
                    <th><label>Especialidad</label></th>
                </tr>
                <tr>
                    <td>
                        <select name="centroMedico" id="sel7">
                        <option value="" >Seleccione centro medico</option>
                        <option value="1">Santiago                </option>
                        <option value="3">Providencia             </option>
                        <option value="4">Estacion Central        </option>
                        </select>                              
                    </td>
                    <td>
                        
                    <select name="especialidadMedica" id="sel8">
                        <option value="">Buscar especialidad   </option>
                        <option value="1">Medicina General     </option>
                        <option value="2">Broncopulmonar       </option>
                        <option value="3">Pediatria            </option>
                        <option value="4">Cirugía Ortopédica   </option>
                        <option value="5">Cardiología invasiva </option>
                        <option value="6">Gastroenterología    </option>
                        <option value="7">Hematología          </option>
                        <option value="8">Oncología            </option>
                        <option value="9">Dermatología         </option>
                        <option value="10">Radiología          </option>
                        <option value="11">Neumología          </option>
                        <option value="12">Cirugía General     </option>
                    </select>
                    </td>
                </tr>
            </table>
        </div>
        <div class="botones">
            <input type="submit" class="btn-continuar" value="Buscar">
            <input type="button" value="Volver">
        </div>
        </div>
    </form>
</body>
</html>