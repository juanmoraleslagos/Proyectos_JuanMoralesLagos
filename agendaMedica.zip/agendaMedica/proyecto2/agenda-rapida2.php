<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!--<link href="agendar.css" rel="stylesheet" type="text/css">-->
        <link href="agenda-rapida2.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="validacionesAgendaRapida.js"></script>
    </head>
    <body>
        <form class="panel" id="slice">
            <div class='text'>
                  <h1>Reservar hora</h1>
            </div>    
            <div class="div3">
                <div class="titulo">
                    <h2 class="heading-title">Reserva de hora medica</h2>
                </div>
                <div class="panel-body">
                    <table id="customers">
                        <tr>
                          <th><label>Centro médico de preferencia</label></th>
                          <th><label>Especialidad</label></th>
                        </tr>
                        <tr>
                          <td>
                              <select name="centroMedico" id="sel7">
                                <option value="" >Seleccione centro medico</option>
                                <option value="1">Santiago                </option>
                                <option value="3">Providencia             </option>
                                <option value="4">Estacion Central        </option>
                              </select>                              
                          </td>
                          <td>
                              
                            <select name="especialidadMedica" id="sel8">
                                <option value="">Buscar especialidad   </option>
                                <option value="1">Medicina General     </option>
                                <option value="2">Broncopulmonar       </option>
                                <option value="3">Pediatria            </option>
                                <option value="4">Cirugía Ortopédica   </option>
                                <option value="5">Cardiología invasiva </option>
                                <option value="6">Gastroenterología    </option>
                                <option value="7">Hematología          </option>
                                <option value="8">Oncología            </option>
                                <option value="9">Dermatología         </option>
                                <option value="10">Radiología          </option>
                                <option value="11">Neumología          </option>
                                <option value="12">Cirugía General     </option>
                            </select>
                          </td>
                        </tr>
                    </table>
                </div>
                <div class="ng-pristine ng-valid" style="height: 80px;">
                    <br>
                    <a class="btn-continuar" href="" onclick = "return validarAgendaRapida()" style="text-decoration:none;">Buscar<a/>
                    <a class="btn-volver"    href="" style="text-decoration:none;">Volver<a/>
                </div>
            </div>
            <div class="div2">
                
            </div>
        </form>
    </body>
</html>
