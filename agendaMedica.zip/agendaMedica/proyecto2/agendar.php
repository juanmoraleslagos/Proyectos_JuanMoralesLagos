<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="agendar.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="validacionesAgendaRapida.js"></script>
    </head>
    <body>
        <form class="panel" id="slice">
            <div class='text'>
                  <h1>Reservar hora</h1>
            </div>    
            <div class="div1">
                <div class="titulo" style="height: 40px;">
                    <h2 class="heading-title">Reserva de hora medica</h2>
                </div>
                <div class="panel-body">
                    <table id="customers">
                        <tr>
                          <th><label>Centro médico de preferencia</label></th>
                          <th><label>Especialidad</label></th>
                        </tr>
                        <tr>
                          <td>
                              <select name="centroMedico" id="sel4">
                               
                              </select>
                          </td>
                          <td>
                              <select name="especialidadMedica" id="sel5">
                                <option value="0">Seleccione una Especialidad</option>
                            </select>
                          </td>
                        </tr>
                    </table>
                    <br>
                    
                    <label>Seleccione Un Especialista</label>
                    <select name="medicoEspecialidad" id="sel6">
                        <option value="0">Seleccione un Especialista</option>
                    </select> 
                    </div>
                
                <div class="ng-pristine ng-valid" style="height: 80px;">
                    <br>
                    <a class="btn-continuar" href="" onclick = "return validarAgendar()" style="text-decoration:none;">Buscar<a/>
                    <a class="btn-volver"    href="" style="text-decoration:none;">Volver<a/>
                </div>
            </div>
        </form>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">
        </script>
        <script type="text/javascript" src="js/agendar.js"></script>
    </body>
</html>
