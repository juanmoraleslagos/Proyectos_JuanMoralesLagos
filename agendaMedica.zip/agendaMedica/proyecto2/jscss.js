window.onload = function() {
	
}

function Show(idShow, idHide) {
	var hidden_panel = document.getElementById(idShow);
	var visible_panel = document.getElementById(idHide);
	visible_panel.style.visibility = 'hidden';
	hidden_panel.style.visibility = 'visible';
}


