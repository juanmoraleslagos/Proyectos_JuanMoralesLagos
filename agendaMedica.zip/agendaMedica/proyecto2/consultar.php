<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="consultar.css" rel="stylesheet" type="text/css">
        </head>
    <body>
        <form class="panel" id="slice">
            <div class='text'>
                  <h1>Mis reservas</h1>
            </div>    
            <div class="div1">
                <div class="titulo" style="height: 40px;">
                    <h2 class="heading-title">Agenda</h2>
                </div>
                    <div class="panel-body">
                        <h3>Resumen de la solicitud</h3>
                        <br>
                        <div class="area">
                            Area:
                            <b>Kinesiologia</b>
                        </div>
                        <div class="area">
                            Clinica:
                            <b>Hola Hola</b>
                        </div>
                        <label>Clínica / Centro médico y dental: Centro Médico ARAUCO-PARQUE ARAUCO</label>
                         <a class="btn-continuar" href="" style="text-decoration:none;">volver a<a/>
                    </div>
                    <div class="titulo-disponible">
                            <h3>Hora Agendada</h3>    
                    </div>
                <div class="panel-medico" style="height: 100px;">
                    <div class="doctor-block-image">
                        <div class="image">
                            <img class="image" src="https://imagenes.milenio.com/pW8hbvM-VwXmYaM_1O3zTDAOTGg=/958x596/smart/https://www.milenio.com/uploads/media/2017/10/23/cada-de-octubre-celebramos-a.jpg"/>
                        </div>
                        <div class="info-title">
                                    <label class="ng-binding">Clínica REDSALUD VITACURA (EX TABANCURA)</label>
                               </div>
                                <div class="doctor-title ng-binding">RICARDO SEBASTIAN CHACON ROJAS></div>
                                <div class="doctor-info-title ng-binding">ACUPUNTURA</div>
                    </div>
                </div>
                    <div class="panel-botones" style="height: 80px;">
                        <br>
                        <a class="btn-continuar" href="" style="text-decoration:none;">Anular<a/>
                        <a class="btn-volver" href="" style="text-decoration:none;">Volver<a/>
                    </div>
                </div>
            </div>    
        </form>
    </body>
</html>
