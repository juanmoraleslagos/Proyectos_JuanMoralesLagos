<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="panel-agendar.css" rel="stylesheet" type="text/css">
        <title></title>
    </head>
    <body>
        <form>
            <!--Margen-->
            <div class="header-x"></div>
            <!--Panel de inicio--> 
        <div class="div1">
            <div class="panel panel-primary">
                <!--panel superior-->
                <div class="panel-heading" style="height: 200px;">
                    <h2 class="heading-title"> 
                        Reservar Hora
                    </h2>
                    <br>
                    <a class="btn-reservar" href="agendar.php" style="text-decoration:none;">Reservar Hora</a>
                    <br>
                    <br>
                    <a class="btn-rapida" href="agenda-rapida.php" style="text-decoration:none;">Agendar Hora Medica Rapida</a>
                    <br>
                    <br>
                    <a class="btn-anular" href="anular.php" style="text-decoration:none;">Anular Hora Medica</a>
                    <br>
                </div>
                <!--panel inferior-->
                <div class="panel-body" style="height: 168px;"> 
                    <h2 class="heading-title">Servicios en línea</h2>
                    <br>
                    <a class="btn-consultar" href="consultar.php" style="text-decoration:none;">Consultar Mis horas medicas</a>
                    <br>
                    <br>
                    <a class="btn-cerrar" href="index.php" style="text-decoration:none;">Cerrar Seccion</a>
                </div>
            </div>
        </div>
        </form>
    </body>
</html>
