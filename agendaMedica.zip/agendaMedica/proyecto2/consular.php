<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="consultar.css" rel="stylesheet" type="text/css"> 
        <title></title>
    </head>
    <body>
         <div class="primer-div">
            <label class="titulo">Mis Reservas</label>
         </div>
        <form class="resumen">
            <div class="resumen-reservas">
                <label>Aqui ira el resumen medio</label>
                <p>Resumen de la solicitud.
                    Clínica / Centro médico y dental.
                    Especialidad
                </p>
            </div>
            <div class="link">
                <a class="volver" href="">Volver al menu</a>
            </div>
            <hr>
            <div class="limpiar"></div>
            <div class="doctor-block-wrapper">
                <div class="doctor-block-title ng-binding">Reservas</div>
                <div class="slotInfoComponent">
                    <div class="doctor-block-image">
                        <div class="image">
                            <img ng-src="https://proxy.megasalud.cl/AWAPatients/Physicians(ed482faf-e424-409e-b9ec-a5f9003e11ef)/GetPicture" src="https://proxy.megasalud.cl/AWAPatients/Physicians(ed482faf-e424-409e-b9ec-a5f9003e11ef)/GetPicture">
                        </div>
                    </div>
                    <div class="doctor-block-info">
                        <div class="doctor-info-table">
                            <div class="info-title">
                                <label ng-class="{'different-center': $ctrl.slotInfo.isSameCenter === false}" class="ng-binding">Centro Médico y Dental PEDRO DE VALDIVIA - PROVIDENCIA</label>          
                            </div><!-- ngIf: $ctrl.displayResourceName -->
                            <div class="doctor-title ng-binding ng-scope" ng-if="$ctrl.displayResourceName">XAVIER JUAN FELIU Z</div><!-- end ngIf: $ctrl.displayResourceName -->
                            <div class="doctor-info-title ng-binding">ALERGOLOGIA</div>
                        </div>
                    </div>

                </div>
                <div class="doctor-time-block">
                    <div class="time-btn-blocks" ng-class="{ 'show-more-time-blocks' : $ctrl.showMoreSelected }"><!-- ngRepeat: slotDay in $ctrl.slotsDaysToDisplay -->
                        <button class="time-btn ng-scope" ng-repeat="slotDay in $ctrl.slotsDaysToDisplay" ng-click="$ctrl.goToSlotDetails(slotDay)"><span class="desktop-view ng-binding">lunes 08 abril</span><span class="mobile-view ng-binding">08-04</span></button><!-- end ngRepeat: slotDay in $ctrl.slotsDaysToDisplay -->
                        <button class="time-btn ng-scope" ng-repeat="slotDay in $ctrl.slotsDaysToDisplay" ng-click="$ctrl.goToSlotDetails(slotDay)"><span class="desktop-view ng-binding">miércoles 10 abril</span><span class="mobile-view ng-binding">10-04</span></button><!-- end ngRepeat: slotDay in $ctrl.slotsDaysToDisplay -->
                        <button class="time-btn ng-scope" ng-repeat="slotDay in $ctrl.slotsDaysToDisplay" ng-click="$ctrl.goToSlotDetails(slotDay)"><span class="desktop-view ng-binding">viernes 12 abril</span><span class="mobile-view ng-binding">12-04</span></button>
                        <!-- end ngRepeat: slotDay in $ctrl.slotsDaysToDisplay -->
                    </div>
                    <div class="clear"></div>
                    <a class="time-link ng-binding" ng-click="$ctrl.showMore($ctrl.showMoreSelected = !$ctrl.showMoreSelected)">Ver otros días disponibles</a>
                </div>
            </div>
        </form>
    </body>
</html>
